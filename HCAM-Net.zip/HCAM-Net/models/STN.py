import torch
import torch.nn as nn
import torch.nn.functional as nnf
import torch.nn.functional as F

class SpatialTransformer(nn.Module):
    """
    N-D Spatial Transformer
    Obtained from https://github.com/voxelmorph/voxelmorph
    """

    def __init__(self, size, mode='bilinear'):
        super().__init__()

        self.mode = mode

        # create sampling grid
        vectors = [torch.arange(0, s) for s in size]
        grids = torch.meshgrid(vectors)
        grid = torch.stack(grids)
        grid = torch.unsqueeze(grid, 0)
        grid = grid.type(torch.FloatTensor)

        # registering the grid as a buffer cleanly moves it to the GPU, but it also
        # adds it to the state dict. this is annoying since everything in the state dict
        # is included when saving weights to disk, so the model files are way bigger
        # than they need to be. so far, there does not appear to be an elegant solution.
        # see: https://discuss.pytorch.org/t/how-to-register-buffer-without-polluting-state-dict
        self.register_buffer('grid', grid)

    def forward(self, src, flow):
        # new locations
        new_locs = self.grid + flow
        shape = flow.shape[2:]

        # need to normalize grid values to [-1, 1] for resampler
        for i in range(len(shape)):
            new_locs[:, i, ...] = 2 * (new_locs[:, i, ...] / (shape[i] - 1) - 0.5)

        # move channels dim to last position
        # also not sure why, but the channels need to be reversed
        if len(shape) == 2:
            new_locs = new_locs.permute(0, 2, 3, 1)
            new_locs = new_locs[..., [1, 0]]
        elif len(shape) == 3:
            new_locs = new_locs.permute(0, 2, 3, 4, 1)
            new_locs = new_locs[..., [2, 1, 0]]

        return nnf.grid_sample(src, new_locs, align_corners=True, mode=self.mode)


class register_model(nn.Module):
    def __init__(self, img_size=(512, 512), mode='bilinear'):
        super(register_model, self).__init__()
        self.spatial_trans = SpatialTransformer(img_size, mode)

    def forward(self, x):
        img = x[0].cuda()
        flow = x[1].cuda()
        out = self.spatial_trans(img, flow)
        return out


class gaussian_register_model(nn.Module):
    def __init__(self, img_size=(512, 512), mode='bilinear'):
        super(gaussian_register_model, self).__init__()
        self.spatial_trans = SpatialTransformer(img_size, mode)
        self.gaussian_kernel = self.create_gaussian_kernel()

    def create_gaussian_kernel(self):
        # 3x3 Gaussian kernel with sigma=1
        kernel = torch.tensor([[1.0, 2.0, 1.0],
                               [2.0, 4.0, 2.0],
                               [1.0, 2.0, 1.0]])
        kernel = kernel / kernel.sum()
        kernel = kernel.view(1, 1, 3, 3)  # reshaping for conv2d
        return kernel

    def gaussian_filter(self, flow):
        # Apply Gaussian filter separately on the two channels (x and y of flow)
        flow_x = flow[:, 0:1, :, :]
        flow_y = flow[:, 1:2, :, :]

        flow_x = F.conv2d(flow_x, self.gaussian_kernel, padding=1)
        flow_y = F.conv2d(flow_y, self.gaussian_kernel, padding=1)

        # Concatenate the channels back together
        filtered_flow = torch.cat([flow_x, flow_y], dim=1)
        return filtered_flow

    def forward(self, x):
        img = x[0].cuda()
        flow = x[1].cuda()

        # Apply Gaussian filter to flow
        filtered_flow = self.gaussian_filter(flow)

        # Perform spatial transformation using the filtered flow
        out = self.spatial_trans(img, filtered_flow)
        return out