import os
import torch
import glob
from torch.utils.data import Dataset
from astropy.io import fits
import numpy as np

class ReadDataset(Dataset):

    def __init__(self, path, transforms):

        fixed = 'fixed/'
        moving = 'moving/'

        fixed_paths = os.path.join(path, fixed)
        moving_paths = os.path.join(path,moving)

        self.fixed_paths = glob.glob(os.path.join(fixed_paths, '*.fits'))
        self.moving_paths = glob.glob(os.path.join(moving_paths, '*.fits'))
        self.transforms = transforms


    def __len__(self):
        return len(self.fixed_paths)

    def __getitem__(self, index):

        with fits.open(self.fixed_paths[index]) as hdu1:
            fixed_array = hdu1[0].data
            fixed_array = (fixed_array - fixed_array.min()) / (fixed_array.max() - fixed_array.min())
        with fits.open(self.moving_paths[index]) as hdu2:
            moving_array = hdu2[0].data
            moving_array = (moving_array - moving_array.min()) / (moving_array.max() - moving_array.min())
        fixed_array = fixed_array[None, ...]
        fixed_array = self.transforms(fixed_array)
        tensor_fixed = torch.from_numpy(fixed_array)

        moving_array = moving_array[None, ...]
        moving_array = self.transforms(moving_array)
        tensor_moving = torch.from_numpy(moving_array)

        return tensor_moving, tensor_fixed




class testReadDataset(Dataset):

    def __init__(self, path, transforms, convert_to_float32=False):

        fixed = 'fixed/'
        moving = 'moving/'

        self.convert_to_float32 = convert_to_float32
        fixed_paths = os.path.join(path, fixed)
        moving_paths = os.path.join(path, moving)

        self.fixed_paths = glob.glob(os.path.join(fixed_paths, '*.fits'))
        self.moving_paths = glob.glob(os.path.join(moving_paths, '*.fits'))
        self.transforms = transforms

    def __len__(self):
        return len(self.fixed_paths)

    def __getitem__(self, index):
        with fits.open(self.fixed_paths[index]) as hdu1:
            fixed_array = hdu1[0].data
            fixed_max = fixed_array.max().astype(np.float32)
            fixed_min = fixed_array.min().astype(np.float32)
            fixed_array = (fixed_array - fixed_min) / (fixed_max - fixed_min)


        with fits.open(self.moving_paths[index]) as hdu2:
            moving_array = hdu2[0].data
            moving_max = moving_array.max().astype(np.float32)
            moving_min = moving_array.min().astype(np.float32)
            moving_array = (moving_array - moving_min) / (moving_max - moving_min)


        fixed_array = fixed_array[None, ...]
        fixed_array = self.transforms(fixed_array)
        tensor_fixed = torch.from_numpy(fixed_array)

        moving_array = moving_array[None, ...]
        moving_array = self.transforms(moving_array)
        tensor_moving = torch.from_numpy(moving_array)

        fixed_filename = os.path.basename(self.fixed_paths[index])
        moving_filename = os.path.basename(self.moving_paths[index])
        #
        # result = (
        # tensor_moving, tensor_fixed, fixed_max, fixed_min, moving_max, moving_min, fixed_filename, moving_filename)
        #
        # return result
        # 返回8个元素
        return tensor_moving, tensor_fixed, fixed_max, fixed_min, moving_max, moving_min, fixed_filename, moving_filename




